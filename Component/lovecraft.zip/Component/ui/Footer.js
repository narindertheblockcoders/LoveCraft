import React from 'react'

const Footer = () => {
  return (
    <div>
        
    <div className="footer">
      <div className="container-fluid">
     
       
        <ul>
          <a href="/"><li className="shape-one"></li></a>
          <a href="/coin"><li className="shape-two"></li></a>
          <li className="shape-three" data-bs-toggle="modal" data-bs-target="#staticBackdrop"> <img src="" alt=""/>
            {/* <!-- Modal --> */}
                
               
    
          <div className="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div className="modal-dialog">
              
              <div className="modal-content">
                
                <div className="modal-header1">
               
                  <button type="button" className="btn" data-bs-dismiss="modal" aria-label="#"> <img className="close-btn1" src="/popup-btn.png" alt=""/></button> 
                  <div id="carouselExampleControlsNoTouching" className="carousel slide" data-bs-touch="false" data-bs-interval="false">
                    <div className="carousel-inner">
                      <div className="carousel-item active">
                        <img src="/slider-1.jpg" className="d-block w-100" alt="..."/>
                      </div>
                   
                      <div className="carousel-item">
                        <img src="/slider-2.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-3.jpg" className="d-block w-100" alt="..."/>
                      </div>
            
                      <div className="carousel-item">
                        <img src="/slider-4.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-5.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-6.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-7.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-8.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-9.jpg" className="d-block w-100" alt="..."/>
                      </div>
            
                      <div className="carousel-item">
                        <img src="/slider-10.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-11.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-12.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-13.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-14.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-15.jpg" className="d-block w-100" alt="..."/>
                      </div>
            
                      <div className="carousel-item">
                        <img src="/slider-16.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-17.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-18.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-19.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-20.jpg" className="d-block w-100" alt="..."/>
                      </div>  
                      <div className="carousel-item">
                        <img src="/slider-21.jpg" className="d-block w-100" alt="..."/>
                      </div>
            
                      <div className="carousel-item">
                        <img src="/slider-22.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-23.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-24.jpg" className="d-block w-100" alt="..."/>
                      </div>
                      <div className="carousel-item">
                        <img src="/slider-25.jpg" className="d-block w-100" alt="..."/>
                      </div>
                    </div>
                    <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
                      <span className="carousel-control" aria-hidden="true"> 
                      <img className="arrowleft" src="/arrowleft.png" alt=""/></span>
                      <span className="visually-hidden">Previous</span>
                    </button>
                    <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
                      <span className="carousel-control" aria-hidden="true">
                        <img className="arrowright" src="/arrowright.png" alt=""/>
                      </span>
                      <span className="visually-hidden">Next</span>
                    </button>
                  </div>
                 
              
                  </div>
            
            
            
                  </div>
        </div>
        </div>
        </li>

        
      <a href="/whitepaper.pdf" target="_blank" className="shape-four"><img src="#" alt=""/></a>
        <a href="/vault">   <li className="shape-five"><img src="" alt=""/></li></a>
        
        </ul>
     
  </div></div>
  <script src="js/bootstrap.bundle.min.js"></script>

    </div>

  )
}


export default Footer