import React from 'react'

const RealCthulhu = () => {
  return (
    <div>
            <section className="home-main-sec7">
        <div className="container">
            <div className="row">
                <div className="col-md-4 cthulhu-right">
                    <img src="/cthulhu-grafics.png" alt=""/>
                    <div className="left-shapes">
                       <p>the narrative</p> 

                    </div>
             

                </div>
                <div className="col-md-8 cthulhu-left">
                    <h1>Coming Soon!</h1>
                    <h2>this upcoming game is an epic adventure set in the
                        world of horror legend h.p. lovecraft. utilizing
                        many of the design features of our real fantasy
                        game, real cthulhu will be an even more ambitious
                        gps experience. </h2>
                        <h2>like all lovecraft labs games, real cthulhu will also
                            be a  part of our play-to-earn model with lovecraft
                            coins, game assets and rare nfts all up for grabs! </h2>
                            <ul className="cthulhu-ul">
                                <li className="cthulhu-box"> <img src="/value-box-7.png" alt=""/></li>
                                <li className="cthulhu-box"> <img src="/value-box-2.png" alt=""/></li>
                                <li className="cthulhu-box"> <img src="/value-box-8.png" alt=""/></li>
                                <li className="cthulhu-box"> <img src="/value-box-4.png" alt=""/></li>
                            </ul>
                            <h2>more about real fantasy can be found in our
                                business plan and company whitepaperl</h2>
               
                </div>   
            </div>
        </div>

  
    
</section>
    
    </div>
  )
}

export default RealCthulhu