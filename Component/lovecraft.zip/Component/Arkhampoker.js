import React from 'react'

const Arkhampoker = () => {
  return (
    <div>
        
    <section className="home-main-sec4">
        <div className="container">
            <div className="col-md-6 poker-left">
                <h1>Coming Soon!</h1>
                <h2>earn lovecraft coins! Win gold
                    for our upcoming game releases!</h2>
                    <h2 style={{textDecoration: "underline"}}>maybe even score a rare artifact nft</h2>
                    <h2>each entry consists of 10 draw
                        poker hands. earn points for
                        each final hand. rewards 
                        based on the total for all
                        10 hands! </h2>
            </div>
            <div className="col-md-6 poker-right">
                <img src="/tash-akrm.png" alt=""/>
                <ul className="mid-main">
                    <li><img className="mid-left"  src="/akrm-mid-1.png" alt=""/></li>
                    <li><img className="mid-right" src="/akrm-mid-2.png" alt=""/></li>
                </ul>
            </div>
           </div>
        
    </section>
    
    </div>
  )
}

export default Arkhampoker