import React from 'react'
import Coin from '../Component/Coin'


const fantasy = () => {
  return (
    <div>
       <Coin/>
    </div>
  )
}

export default fantasy