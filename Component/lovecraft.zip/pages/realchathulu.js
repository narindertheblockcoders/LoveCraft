import React from 'react'
import RealCthulhu from '../Component/RealCthulhu'

const realchathulu = () => {
  return (
    <div>
        <RealCthulhu/>
    </div>
  )
}

export default realchathulu