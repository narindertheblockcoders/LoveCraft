import React from 'react'
import Vault from '../Component/Vault'

const vault = () => {
  return (
    <div>
        <Vault/>
    </div>
  )
}

export default vault