import React from 'react'
import Arkhampoker from '../Component/Arkhampoker'

const arkhampoker = () => {
  return (
    <div>
        <Arkhampoker/>
    </div>
  )
}

export default arkhampoker