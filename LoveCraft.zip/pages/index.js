import React from 'react'
import FrontPage from '../Component/FrontPage'

const index = () => {
  return (
    <div>
      <FrontPage/>
    </div>
  )
}

export default index