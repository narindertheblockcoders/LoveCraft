import React from 'react'
import DungeonRun from '../Component/DungeonRun'

const dungeonrun = () => {
  return (
    <div>
        <DungeonRun/>
    </div>
  )
}

export default dungeonrun