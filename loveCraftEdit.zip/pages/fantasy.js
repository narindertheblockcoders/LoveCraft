import React from 'react'
import Fantasy from '../Component/Fantasy'

const fantasy = () => {
  return (
    <div>
        <Fantasy/>
    </div>
  )
}

export default fantasy