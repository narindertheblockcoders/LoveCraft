import React from 'react'

const BussinessModal = () => {
  return (
    <div>
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-margin" >
                          
                          <div class="modal-content content-modal">
                            
                            <div class="modal-header1">
                           
                              <button type="button" class="btn" data-bs-dismiss="modal" aria-label="#"> 
                              <img class="close-btn1" src="/popup-btn.png" alt=""/></button> 
                              <div id="carouselExampleControlsNoTouching" class="carousel slide" data-bs-touch="false" data-bs-interval="false">
                                <div class="carousel-inner inner-carousel">
                                  <div class="carousel-item active">
                                    <img src="/slider-1.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                               
                                  <div class="carousel-item">
                                    <img src="/slider-2.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-3.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                        
                                  <div class="carousel-item">
                                    <img src="/slider-4.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-5.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-6.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-7.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-8.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-9.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                        
                                  <div class="carousel-item">
                                    <img src="/slider-10.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-11.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-12.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-13.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-14.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-15.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                        
                                  <div class="carousel-item">
                                    <img src="/slider-16.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-17.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-18.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-19.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-20.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-21.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                        
                                  <div class="carousel-item">
                                    <img src="/slider-22.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-23.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-24.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                  <div class="carousel-item">
                                    <img src="/slider-25.jpg" class="d-block w-100" alt="..."/>
                                  </div>
                                </div>
                                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
                                  <span class="carousel-control" aria-hidden="true"> <img class="arrowleft" id='arrow-set' src="/arrowleft.png" alt=""/></span>
                                  <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
                                  <span class="carousel-control" aria-hidden="true"><img class="arrowright" id='arrow-right' src="/arrowright.png" alt=""/>
                                  </span>
                                  <span class="visually-hidden">Next</span>
                                </button>
                              </div>
                             
                          
                              </div>
                        
                          </div>
                        </div>
                        </div>
    </div>
  )
}

export default BussinessModal